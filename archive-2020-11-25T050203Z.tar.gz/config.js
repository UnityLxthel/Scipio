module.exports = {
    admins: ["265240267215339522"], //put the "admins" of the bot here, this will give them access to commands marked with `adminOnly: true`
    token: "NzY5MzE1OTg3ODI0NDQzNDIy.X5NPWA.akDuqR2bKqXJ9Kned0t1vU_GiII", //bot's login token from the discord developer page
    prefix: "!" //prefix that the command calls should start with
}
//any changes to this file will require a full bot restart to update