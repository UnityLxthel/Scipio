const Discord = require("discord.js");

module.exports = {
    name: "", //must match the file name minus the .js
    globalfunction1,
    globalfunction2
}

async function globalfunction1(){
    //do stuff
}
function globalfunction2(){
    //do stuff
}